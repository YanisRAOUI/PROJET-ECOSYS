#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "ecosys.h"

int main(){
	//création des listes de proies et prédateurs initialisées à null
 	Animal *liste_proie = NULL;
 	Animal *liste_predateur = NULL;
 	int energie=10;  //pose l'énergie initiale des animaux à 10
 
	srand(time(NULL)); //initialise le générateur pseudo-aléatoire

	//création d'une liste de 20 proies, avec des positions aléatoires à chaque fois
	for (int i = 0; i < 20; i++) {
		int x = rand() % SIZE_X; 
        int y = rand() % SIZE_Y;
        ajouter_animal(x, y, 10.0f, &liste_proie); 
    }

	//création d'une liste de 20 prédateurs, avec des positions aléatoires à chaque fois
	for (int j = 0; j < 20; j++) {
        int x = rand() % SIZE_X;
        int y = rand() % SIZE_Y;
        ajouter_animal(x, y, 10.0f, &liste_predateur); 
    }

	ecrire_ecosys("ecosystem.txt", liste_predateur, liste_proie); //écrit dans un fichier les listes de proies/prédateurs
	
	//affiche le nombre de proies et prédateurs
	printf("Nombre de proies : %d\n", compte_animal_it(liste_proie));
    printf("Nombre de prédateurs : %d\n", compte_animal_it(liste_predateur));

	afficher_ecosys(liste_proie, liste_predateur);  //affiche l'ecosystème composé des deux listes
				
    enlever_animal(&liste_proie, liste_proie->suivant);  //retrait d'une 1ere proie        
    enlever_animal(&liste_predateur, liste_predateur->suivant); //retrait d'un 1ere prédateur  

	//retrait d'une 2e proie  
    Animal *predateur_num_quatre = liste_predateur;
    for (int k = 0; k < 3 && predateur_num_quatre; k++) {
        predateur_num_quatre = predateur_num_quatre->suivant;
    }   
    enlever_animal(&liste_predateur, predateur_num_quatre);
   
	//retrait d'un 2e prédateur
    Animal *proie_num_cinq = liste_proie;
    for (int l = 0; l < 4 && proie_num_cinq; l++) {
        proie_num_cinq = proie_num_cinq->suivant;
    }    
    enlever_animal(&liste_proie, proie_num_cinq);
   
	//affiche le nombre de proies et prédateurs après suppresions de 2 de chaque
    printf("Nombre de proies après suppression : %d\n", compte_animal_it(liste_proie));
    printf("Nombre de prédateurs après suppression : %d\n", compte_animal_it(liste_predateur));

	afficher_ecosys(liste_proie, liste_predateur);  //affiche l'ecosystème composé des deux listes après suppression de 2 proies et 2 prédateurs
    
    //libération des deux listes
    liste_proie = liberer_liste_animaux(liste_proie);
    liste_predateur = liberer_liste_animaux(liste_predateur);
    
    //affiche le nombre de proies et prédateurs après suppresions de tous les éléments
    printf("Nombre de proies après suppression : %d\n", compte_animal_it(liste_proie));
    printf("Nombre de prédateurs après suppression : %d\n", compte_animal_it(liste_predateur));
    
    afficher_ecosys(liste_proie, liste_predateur); //affiche l'ecosystème composé des deux listes après suppression de tous les éléments 
    
	lire_ecosys("ecosystem.txt", &liste_predateur, &liste_proie);  //recrée les deux listes écrites dans le fichier .txt
   
    afficher_ecosys(liste_proie, liste_predateur);  //affiche l'ecosystème représenté par les deux listes écrites dans le fichier .txt

	//libération des deux listes
    liberer_liste_animaux(liste_predateur);
    liberer_liste_animaux(liste_proie);
    return 0;
}












