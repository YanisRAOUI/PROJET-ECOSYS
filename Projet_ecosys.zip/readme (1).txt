Projet réalisé par Yanis RAOUI et Ayoub CHAMMAKHI

Instructions:
-pour compiler => taper "make" dans le terminal
-pour executer=> ./nom_executable 
