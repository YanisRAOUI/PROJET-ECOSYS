//fait par Yanis RAOUI et Ayoub CHAMMAKHI
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ecosys.h"

//Initialisation des variables globales dont on aura besoin pour le projet
float p_ch_dir=0.5;   //Probabilité qu'un animal puisse opérer un changement de direction
float p_reproduce_proie=0.2;
float p_reproduce_predateur=0.2;
int temps_repousse_herbe=-15;

/* PARTIE 1*/
/* Fourni: Part 1, exercice 4, question 2 */

//On crée un animal avec une position x,y, une energie et une direction
Animal *creer_animal(int x, int y, float energie) {
  //On alloue de l'espace memoire pour l'animal
  Animal *na = (Animal *)malloc(sizeof(Animal));
  //On verifie que l'allocation s'est bien realisé
  assert(na);
  //On initialise chaque champ de l'animal
  na->x = x;
  na->y = y;
  na->energie = energie;
  na->dir[0] = rand() % 3 - 1;  
  na->dir[1] = rand() % 3 - 1;
  na->suivant = NULL;
  return na;
}


/* Fourni: Part 1, exercice 4, question 3 */

//On ajoute un animal en tete d'une liste d'animal  
Animal *ajouter_en_tete_animal(Animal *liste, Animal *animal) {
  assert(animal);
  assert(!animal->suivant);
  animal->suivant = liste;
  return animal;
}

/* A faire. Part 1, exercice 6, question 2 */

//On ajoute un animal à une position x,y dans une liste chainé liste_animal, on met un double pointeur dans la liste animal afin de passer un pointeur par adresse et ainsi pouvoir directement le modifier dans la fonction, on aura alors un pointeur sur un pointeur sur un animal 
void ajouter_animal(int x, int y, float energie, Animal **liste_animal) {
    //On verifie que les coordonnées x,y sont positives et inferieures à  SIZE_X et SIZE_Y
    if (x < 0 || x >= SIZE_X || y < 0 || y >= SIZE_Y) {
        printf("On ne peut pas ajouter à la liste : coordonnées (%d, %d) hors limites\n", x, y);
        return;
    }
    Animal *p = creer_animal(x, y, energie);
    p->suivant = *liste_animal;
    *liste_animal = p;
}


/* A Faire. Part 1, exercice 5, question 5 */

//On supprime un animal de la liste_animal 
void enlever_animal(Animal **liste, Animal *animal) {
    if (liste==NULL || *liste==NULL || animal==NULL){
    	return; 
    }
    Animal *courant = *liste;
    Animal *pre = NULL;

    while (courant) {
        //On a trouvé l'animal à supprimer
        if (courant == animal) { 
            if (pre) {
                pre->suivant = courant->suivant; 
            } else {
                *liste = courant->suivant; 
            }
            //On le libere et on sort de la fonction car on trouvé l'animal a supprimer
            free(courant); 
            return; 
        }
        pre = courant;
        courant = courant->suivant;
    }
}


/* A Faire. Part 1, exercice 6, question 7 */

//On libere la memoire allouée par la liste
Animal* liberer_liste_animaux(Animal *liste) {
   Animal *temp;
   //On parcourt en liberant chaque case de la liste
   while (liste!=NULL){
   	temp=liste;
   	liste=liste->suivant;
   	free(temp);
   } 
  return NULL;
}

/* Fourni: part 1, exercice 4, question 4 */

//Compte le nombre d'animal de facon recursive, on utilise unsigned au cas ou s'il y a trop d'animaux et que dcp on depasse l'espace memoire que peut detenit un int
unsigned int compte_animal_rec(Animal *la) {
  if (!la) return 0;
  return 1 + compte_animal_rec(la->suivant);
}

/* Fourni: part 1, exercice 4, question 4 */
//Pareil que la fonction precedente mais de facon iterative cette fois ci
unsigned int compte_animal_it(Animal *la) {
  int cpt=0;
  while (la) {
    ++cpt;
    la=la->suivant;
  }
  return cpt;
}



/* Part 1. Exercice 5, question 1, ATTENTION, ce code est susceptible de contenir des erreurs... */

//Ce code permet d'afficher l'ecosysteme
void afficher_ecosys(Animal *liste_proie, Animal *liste_predateur) {
    unsigned int i, j;
    char ecosys[SIZE_X][SIZE_Y];
    Animal *pa = NULL;

    /* on initialise le tableau */
    for (i = 0; i < SIZE_X; ++i) {
        for (j = 0; j < SIZE_Y; ++j) {
            ecosys[i][j] = ' ';
        }
    }

    /* on ajoute les proies */
    pa = liste_proie;
    while (pa) {
        if (pa->x >= 0 && pa->x < SIZE_X && pa->y >= 0 && pa->y < SIZE_Y) {
            ecosys[pa->x][pa->y] = '*';
        }
        pa = pa->suivant;
    }

    /* on ajoute les predateurs */
    pa = liste_predateur;
    while (pa) {
        if (pa->x >= 0 && pa->x < SIZE_X && pa->y >= 0 && pa->y < SIZE_Y) {
            if (ecosys[pa->x][pa->y] == '*') {
                ecosys[pa->x][pa->y] = '@'; // Proie + prédateur
            } else {
                ecosys[pa->x][pa->y] = 'O'; // Prédateur seul
            }
        }
        pa = pa->suivant;
    }

    /* on affiche le tableau */
    printf("+");
    for (j = 0; j < SIZE_Y; ++j) {
        printf("-");
    }
    printf("+\n");
    for (i = 0; i < SIZE_X; ++i) {
        printf("|");
        for (j = 0; j < SIZE_Y; ++j) {
            putchar(ecosys[i][j]);
        }
        printf("|\n");
    }
    printf("+");
    for (j = 0; j < SIZE_Y; ++j) {
        printf("-");
    }
    printf("+\n");

    
    int nbproie = compte_animal_it(liste_proie); 
    int nbpred = compte_animal_it(liste_predateur);

    printf("Nb proies : %5d\tNb predateurs : %5d\n", nbproie, nbpred);
}



void clear_screen() {
  printf("\x1b[2J\x1b[1;1H");  /* code ANSI X3.4 pour effacer l'ecran */
}

/* PARTIE 2*/

/* Part 2. Exercice 4, question 1 */

//On fait bouger tout les animaux de la liste chainee la
void bouger_animaux(Animal *la) {
	while(la){
	        //On verifie aleatoirement si on fait un changement de direction
		if(rand()/(float)RAND_MAX<p_ch_dir){
			la->dir[0]=rand()%3-1;
			la->dir[1]=rand()%3-1;	
		}
		la->x=(la->x+la->dir[0]+SIZE_X)%SIZE_X;
		la->y=(la->y+la->dir[1]+SIZE_Y)%SIZE_Y;
		la=la->suivant;
	}
}

/* Part 2. Exercice 4, question 3 */

//Permet de gerer la reproduction des animaux
void reproduce(Animal **la, float p_reproduce) {
        if(la){
	  Animal *ap= *la;
	  while(ap){
	        //On verifie aleatoirement si on ajoute un nouvel animal
		if(rand()/(float)RAND_MAX<p_reproduce){
			ajouter_animal(ap->x, ap->y, ap->energie/2, la);
			ap->energie= ap->energie/2;
		}
		ap=ap->suivant;
	}
      }
}

//écrits les deux listes dans un fichier .txt
void ecrire_ecosys(const char *nom_fichier, Animal *liste_predateur, Animal *liste_proie){
	FILE *f= fopen(nom_fichier, "w");
	 //ouvre le ficihier ou on va écrire nos deux listes
	//si le fichier ne peut pas être ouvert, on renvoie un msg d'erreur et on sors de la fonction
	if(f==NULL){
		fprintf( stderr, "Erreur lors de l'ouverture du fichier %s.\n", nom_fichier);
		return;
	}
	fprintf(f, "<proies>\n");//balique qui marque le début de la section des proies
	while(liste_proie){
		fprintf(f, "x=%d y=%d dir=[%d %d] e=%f\n", liste_proie->x, liste_proie->y, liste_proie->dir[0], liste_proie->dir[1], liste_proie->energie);//on écrit dans f les infos des proies
		liste_proie= liste_proie->suivant;
	}
	fprintf(f, "</proies>\n<predateurs>\n"); //balise de fin de section proies et de début section prédateurs
	while(liste_predateur){
		fprintf(f, "x=%d y=%d dir=[%d %d] e=%f\n", liste_predateur->x, liste_predateur->y, liste_predateur->dir[0], liste_predateur->dir[1], liste_predateur->energie);//on écrit dans f les infos des prédateurs
		liste_predateur= liste_predateur->suivant;
	}
	fprintf(f, "</predateurs>\n");//fin de section des prédateurs
	fclose(f);//fermeture du fichier
	return;	
}
		
void lire_ecosys(const char* nom_fichier,Animal**liste_predateur,Animal**liste_proie){
  FILE*f=fopen(nom_fichier,"r");
  if(f==NULL){
    fprintf( stderr,"erreur lors de l'ouverture du fichier %s\n",nom_fichier );
    return;
  }
  char buffer[256];
  fgets(buffer,256,f);//lecture de la premiere ligne du fichier
  if(strncmp(buffer,"<proies>",8)!=0){
    fprintf(stderr, "erreur %s n'est pas un fichier d'ecosysteme !\n",nom_fichier );
    exit(-1);
  }
  fgets(buffer,256,f);
  int x_lu, y_lu,dir_lu[2];
  float energie_lu;
  
  while(strncmp(buffer,"</proies>",9)!=0){
    sscanf(buffer,"x=%d y=%d dir=[%d %d] e=%f\n",&x_lu,&y_lu,&dir_lu[0],&dir_lu[1],&energie_lu);
    Animal*a_lu=creer_animal(x_lu,y_lu,energie_lu);
    a_lu->dir[0]=dir_lu[0];
    a_lu->dir[1]=dir_lu[1];
    //ajout en debut de liste ;
    a_lu->suivant=*liste_proie;
    *liste_proie=a_lu;
    fgets(buffer,256,f);
  }

  fgets(buffer,256,f);
  fgets(buffer,256,f);
  while(strncmp(buffer,"</predateurs>",9)!=0){
    sscanf(buffer,"x=%d y=%d dir=[%d %d] e=%f\n",&x_lu,&y_lu,&dir_lu[0],&dir_lu[1],&energie_lu);
    Animal*a_lu=creer_animal(x_lu,y_lu,energie_lu);
    a_lu->dir[0]=dir_lu[0];
    a_lu->dir[1]=dir_lu[1];
    //ajout en debut de liste ;
    a_lu->suivant=*liste_predateur;
    *liste_predateur=a_lu;
    fgets(buffer,256,f);
  }
  assert(strncmp("</predateurs>",buffer,12)==0);
  fclose(f);
}


/* Part 2. Exercice 6, question 1 */

//On met à jour les proies
void rafraichir_proies(Animal **liste_proie, int monde[SIZE_X][SIZE_Y]) {
	if(liste_proie == NULL) return;

	Animal *la = *liste_proie;

	// on fait bouger les proies
	bouger_animaux(la);

	while(la){
		la->energie -= 1.;
		if (monde[la->x][la->y]>=0){
			la->energie += monde[la->x][la->y];
			monde[la->x][la->y] = temps_repousse_herbe; 
    	        }

    	        if(la->energie <= 0){
    		      Animal *tmp = la;
      		      la = la->suivant;
      		      //on supprime les proies mortes
      		      enlever_animal(liste_proie, tmp);
     		      //on quitte cette iteration et on va à la suivante
     		      continue;
   	        }    
    	        //La proie a survecu
    	        la = la->suivant;
  	}
	reproduce(liste_proie, p_reproduce_proie);//on fait reproduire les proies
}


/* Part 2. Exercice 7, question 1 */

//fonction qui cherche si un animal de la liste l est présent aux positions x et y
Animal *animal_en_XY(Animal *l, int x, int y) {
	Animal *p = l; //pointeur vers le 1er animal
	while (p) {//tant qu'on est pas à la fin de la liste
    	if (p->x == x && p->y == y) {//si il est présent
      	return p;//on le renvoie
    	}
    	p = p->suivant; //sinon on passe au suivant
	}
	return NULL;//si aucun animal de la liste n'y est présent on renvoie NULL
}



/* Part 2. Exercice 7, question 2 */
void rafraichir_predateurs(Animal **liste_predateur, Animal **liste_proie) {
        //si liste de prédateurs est vide, on sort de la fonction
	if(liste_predateur == NULL){
		return;
	}
	Animal *la = *liste_predateur; //pointeur vers le 1er elt de la liste de predateur
	// on fait bouger les predateurs
	bouger_animaux(la);
	Animal *proie= NULL;
	while(la){//tant qu'on est pas à la fin de la	liste
		la->energie -= 1.;//on diminue l'énergie du prédateur
		if(liste_proie)//si liste_proie non vide
		    proie= animal_en_XY(*liste_proie, la->x, la->y);//verifie si une proie est au mêmes coordonées que le prédateur
		if (proie){//si c'est le cas
			la->energie += proie->energie;//le prédateur mange la proie 
			enlever_animal (liste_proie,proie); 
    	}
    	 if(la->energie <= 0){//si le prédateur est mort
    		  Animal *tmp = la;
      		  la = la->suivant;//on passe au suivant    
      		  //on supprime les predateurs morts
      		  enlever_animal(liste_predateur, tmp);//on le supprime 

     		 //on quitte cette iteration et on va au suivante
     		 continue;
   	 	}    
    	//si on est arrivee la ca veut dire que la proie a survecu
    	la = la->suivant;
  	}
	reproduce(liste_predateur, p_reproduce_predateur);//on fait reproduire les prédateurs
}




/* Part 2. Exercice 5, question 2 */

//Cette fonction permet d'incrementé de 1 la quantité d'herbe a chaque case pour chaque iteration de la simulationbb
void rafraichir_monde(int monde[SIZE_X][SIZE_Y]){
    for(int i = 0; i < SIZE_X; i++){
      for(int j = 0; j < SIZE_Y; j++){
        monde[i][j] += 1;
      }
    }
}


