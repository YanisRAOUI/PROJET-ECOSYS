
#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <strings.h>
#include "ecosys.h"

#define NB_PROIES 20
#define NB_PREDATEURS 20
#define T_WAIT 40000
#define ITER 500

int main(void) { 
	float energie=10.0;
	// exercice 4, questions 2 et 4 
	srand(time(NULL));
	Animal *liste1 = NULL;   
	ajouter_animal(10,10,10,&liste1); //ajouter un animal à liste1 en position x=10, y=10 et energie=10
	Animal *liste2 = NULL;
	
	afficher_ecosys(liste1, liste2);  //affiche l'ecosystème composé des deux listes
	bouger_animaux(liste1);	   //fait bouger liste1, qui contient 1 seul animal
	afficher_ecosys(liste1, liste2);  //réaffiche l'écosystème pour vérifier que le déplacement ait bien été fait
        
         liberer_liste_animaux(liste1);
	Animal *proie= NULL;
        //On crée 20 proies
        for (int i=0 ; i < NB_PROIES; i++){
          Animal *new = creer_animal(rand()%SIZE_X,rand()%SIZE_Y, energie);
          proie = ajouter_en_tete_animal(proie,new);
        }
        Animal *predateur= NULL;
        
        //On crée 20 predateurs
        for (int j=0 ; j < NB_PREDATEURS; j++){
          Animal *new = creer_animal(rand()%SIZE_X,rand()%SIZE_Y, energie);
          predateur = ajouter_en_tete_animal(predateur,new);
        }
        afficher_ecosys(proie, predateur);
        
        int monde[SIZE_X][SIZE_Y] = {0};//déclaration du monde dans lequel va se dérouler la simulation, qu'on initialise avec que des cellules vides
        
        FILE *f=fopen("Evol_Pop.txt", "w");//création d'un fichier ou on va noter l'évolution des animaux au fil des tours
        
        //boucle de la simulation
        int k=0;
        while (k < ITER && (proie && predateur)){//tant qu'on a pas dépassé le nombre max d'itération et qu'on a encore des animaux
          
            rafraichir_monde(monde); // Rafraîchissement du monde (mis à jour de l'herbe)
            rafraichir_proies(&proie, monde); // Rafraîchissement des proies (déplacements, reproduction)
            rafraichir_predateurs(&predateur,&proie);// Rafraîchissement des prédateurs (déplacements, reproduction)
            afficher_ecosys(proie, predateur);//affichage du monde à chaque tour
            usleep(T_WAIT); // Attente pour ralentir la simulation
            
            fprintf(f, "%d %d %d\n", k, compte_animal_it(proie), compte_animal_it(predateur));//notation dans le fichier du tour et du nombre d'animaux (proies et prédateurs)
            k++;
            printf("on est au %dième tour\n", k);
        }
        
        
        printf("\n");
        
        if (compte_animal_it(proie)>compte_animal_it(predateur))
			printf("Les proies ont gagné  :) , et on a fait %d itérations\n", k);
		if (compte_animal_it(proie)<compte_animal_it(predateur))
			printf("Les predateurs ont gagné :( , et on a fait %d itérations\n", k);
		if(compte_animal_it(proie)==compte_animal_it(predateur))
			printf("Egalité :| , et on a fait %d itérations\n", k);
			
        liberer_liste_animaux(proie);
        liberer_liste_animaux(predateur);
  fclose(f);
  return 0;
}

