#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#include "ecosys.h"



int main(void) {
	int i;
	//création des listes de proies et prédateurs initialisées à null
	Animal *liste_proie = NULL;
	Animal *liste_predateur = NULL;
	int energie=10;  //pose l'énergie initiale des animaux à 10

	srand(time(NULL)); //initialise le générateur pseudo-aléatoire

	//création de 4 animaux (futures proies), avec des positions différentes mais la même énergie
	Animal *a1 = creer_animal(0,10, energie);
	Animal *a2 = creer_animal(15,35, energie);
	Animal *a3 = creer_animal(2,42, energie);
	Animal *a4 = creer_animal(18,13, energie);
  
	//création manuelle de la chaine d'animaux  
	a1->suivant=a2;
	a2->suivant=a3;
	a3->suivant=a4;
	
	liste_proie=a1; //déclare la liste qui commence par a1 comme liste de proies

	//création de 4 animaux (futures prédateurs), avec des positions différentes mais la même énergie
	Animal *a5 = creer_animal(2,5, energie);
	Animal *a6 = creer_animal(15,35, energie);
	Animal *a7 = creer_animal(9,22, energie);
	Animal *a8 = creer_animal(17,3, energie);
  
    //création manuelle de la chaine d'animaux 
	a5->suivant=a6;
	a6->suivant=a7;
	a7->suivant=a8;

	liste_predateur=a5; //déclare la liste qui commence par a5 comme liste de proies
  
        
	afficher_ecosys(liste_proie,liste_predateur);  //affiche l'ecosystème composé des deux listes
        
        liberer_liste_animaux(liste_predateur);
        liberer_liste_animaux(liste_proie);
	return 0;
}
